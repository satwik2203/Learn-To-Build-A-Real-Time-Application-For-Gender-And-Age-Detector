# Car Colour Detection Project (Synthetic Demo)
This repository is a self-contained demo for the assignment "Car colour detection Model".
It uses a synthetic dataset (colored rectangles representing cars and small circles representing people) to train a lightweight sklearn model to classify car colours and a simple Tkinter GUI for demoing detection and counting people.

What is included:
- model_files/model.joblib : Trained sklearn model (small, trained on synthetic images)
- train.ipynb : Jupyter notebook that shows dataset generation, training, metrics (confusion matrix, precision, recall)
- app.py : Tkinter GUI that lets you open an image or use a sample; shows rectangles and people count.
- requirements.txt : Python packages required
- README.md : This file

Notes & Limitations:
- The dataset is synthetic and simplified (rectangles as cars), so the model is not for real-world deployment.
- The GUI demonstrates the requested features: blue cars get a red rectangle drawn; other colours get blue rectangles; people count is shown.
- For real-world use you should train on annotated real images (COCO/Pascal VOC) and use an object detection model (YOLO, SSD, Faster R-CNN).


## Single-notebook version
Use `project_notebook.ipynb` to run everything (dataset, training, evaluation and in-notebook GUI using ipywidgets).
