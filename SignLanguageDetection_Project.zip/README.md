# Sign Language Detection

This project detects and classifies sign language gestures into known words using a CNN-based deep learning model.

## Features
- Image upload and real-time video prediction
- Time-based restriction (active from 6 PM to 10 PM)
- GUI interface in Jupyter Notebook
- Metrics: Accuracy, Confusion Matrix, Precision, Recall, F1 Score

## Project Structure
- notebooks/: Jupyter notebooks for training and GUI
- saved_models/: Trained models (upload here, large files should be linked via Google Drive)
- weights/: Model weights (if separate)
- gui/: GUI implementations if extended

## Submission Guidelines Followed
- requirements.txt provided
- Entire workflow in Jupyter Notebook
- Model, weights, and notebook stored in respective folders
- Google Drive links can be added for large files

## Accuracy
Model achieves >70% accuracy on test data.

## Usage
1. Install dependencies: `pip install -r requirements.txt`
2. Open the notebook inside `notebooks/`
3. Train the model or load saved weights
4. Use GUI for image upload or real-time detection

