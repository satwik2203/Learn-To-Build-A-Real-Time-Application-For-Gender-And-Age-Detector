import streamlit as st
import numpy as np, os, joblib, librosa
st.title("Age and Emotion Detection (Voice) - Demo GUI")
st.write("Upload a voice note. App accepts only male voices. If a female voice is detected, it rejects with message 'Upload male voice.' For male voices, it predicts age; if age>60, it marks senior citizen and detects emotion.")

uploaded = st.file_uploader("Upload WAV/MP3", type=["wav","mp3","ogg","flac"])
if uploaded is not None:
    # save temporary file
    temp_path = os.path.join("temp_audio.wav")
    with open(temp_path, "wb") as f:
        f.write(uploaded.getbuffer())
    # extract features (same as notebook)
    try:
        y, sr = librosa.load(temp_path, sr=22050)
        mfcc = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=13)
        mfcc_mean = np.mean(mfcc, axis=1)
        spec_cent = np.mean(librosa.feature.spectral_centroid(y=y, sr=sr))
        zcr = np.mean(librosa.feature.zero_crossing_rate(y))
        try:
            f0 = librosa.yin(y, fmin=50, fmax=400, sr=sr)
            f0_med = float(np.nanmedian(f0))
            if np.isnan(f0_med):
                f0_med = 0.0
        except Exception as e:
            f0_med = 0.0
        feats = np.hstack([mfcc_mean, spec_cent, zcr, f0_med]).reshape(1,-1)
    except Exception as e:
        st.error("Could not process audio: " + str(e))
        feats = None

    # simple pitch-based gender check
    if feats is not None:
        f0 = feats[0,-1]
        if f0 > 160.0:
            st.warning("Upload male voice.")
        else:
            # try to load models
            saved_dir = os.path.join(os.path.dirname(__file__), "..", "saved_model")
            age_model_path = os.path.join(saved_dir, "age_model.joblib")
            emotion_model_path = os.path.join(saved_dir, "emotion_model.joblib")
            le_path = os.path.join(saved_dir, "emotion_label_encoder.joblib")
            if not os.path.exists(age_model_path):
                st.info("Age model not found. Run notebooks/train_model.ipynb to train the models and produce saved_model/age_model.joblib")
                # fallback: show heuristic age estimate: map pitch to age roughly
                est_age = int(max(15, min(85, 200 - f0)))  # very rough heuristic
                st.write("Estimated age (heuristic):", est_age)
            else:
                age_model = joblib.load(age_model_path)
                pred_age = age_model.predict(feats)[0]
                st.write("Predicted age:", float(pred_age))
                if pred_age > 60:
                    st.write("Marked as: Senior citizen (age > 60). Detecting emotion...")
                    if not os.path.exists(emotion_model_path):
                        st.info("Emotion model not found. Run the notebook to train emotion model.")
                    else:
                        emo_model = joblib.load(emotion_model_path)
                        le = joblib.load(le_path)
                        emo_pred_num = emo_model.predict(feats)[0]
                        emo_label = le.inverse_transform([emo_pred_num])[0]
                        st.write("Detected emotion:", emo_label)
    # cleanup
    try:
        os.remove(temp_path)
    except:
        pass
