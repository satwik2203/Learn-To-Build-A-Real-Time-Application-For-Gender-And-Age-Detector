
# Age and Emotion Detection through Voice - Project Submission

This project implements the assignment:
- Detect gender (male/female) from an uploaded voice note. If female, reject with message "Upload male voice."
- For male voices: predict age. If age > 60, mark as senior citizen and also detect emotion; else only show predicted age.

Contents:
- `notebooks/train_model.ipynb` : Jupyter notebook that generates synthetic audio (sine waves), extracts features using librosa, trains simple models for age regression and emotion classification, and saves models to `saved_model/`.
- `app/streamlit_app.py` : Streamlit GUI that accepts audio upload and runs the described logic. Uses a pitch-based heuristic to filter female voices; the notebook shows how to train a model if you prefer ML-based gender detection.
- `saved_model/` : placeholder directory where the notebook will save trained models (`age_model.h5`, `emotion_model.h5`).
- `sample_audio/` : contains a few synthetic sample WAV files to test the GUI.
- `requirements.txt` : required Python packages.
- `README.md` : this file.

Notes:
- The notebook is runnable end-to-end to produce trained models. Run it locally in Jupyter to create the saved models, or modify thresholds as needed.
- The gender detection in the notebook uses a simple pitch-based heuristic (mean fundamental frequency) as a fast, interpretable rule; the notebook also includes an example of training a classifier.
