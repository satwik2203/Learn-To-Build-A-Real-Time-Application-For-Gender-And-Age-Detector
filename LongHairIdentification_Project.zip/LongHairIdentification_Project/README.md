
# Long Hair Identification - Project Submission

This project implements the *Long Hair Identification* task described by the user.
It contains:

- `notebooks/train_model.ipynb` : Jupyter notebook that generates a synthetic dataset, trains a simple CNN+age-input model, evaluates it, and saves the model (`saved_model/model.h5`).
- `saved_model/` : (empty placeholder). If you run the notebook it will create the model at `saved_model/model.h5`.
- `app/streamlit_app.py` : Streamlit GUI to upload an image and enter age; uses the saved model to predict gender considering the special age-and-hair-length rule encoded in the training labels.
- `requirements.txt` : packages required.
- `README.md` : this file.
- `metrics/` : will contain metrics after running the notebook.
- `dataset_sample/` : contains small sample synthetic images used by the notebook.

## Notes and Usage

- The model and notebook implement the rule: for people aged **20-30** inclusive, the label used for training maps **long hair -> female**, **short hair -> male** regardless of true gender. For ages outside that range, the label is the true gender.
- The notebook is runnable and contains the full training pipeline in a single `.ipynb` file.
- To run the GUI locally (after installing requirements): `streamlit run app/streamlit_app.py`
- To produce `saved_model/model.h5` run the notebook: open `notebooks/train_model.ipynb` and execute all cells.
