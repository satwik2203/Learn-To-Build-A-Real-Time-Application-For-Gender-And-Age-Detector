import streamlit as st
from PIL import Image
import numpy as np, os, tensorflow as tf

st.title("Long Hair Identification - Demo GUI")
st.write("Upload a face image (synthetic style) and enter age. The model was trained with the special rule: for ages 20-30, long hair -> female; short hair -> male. For ages outside that range, model predicts true gender.")

uploaded = st.file_uploader("Upload image (PNG/JPG)", type=["png","jpg","jpeg"])
age = st.number_input("Age", min_value=1, max_value=120, value=25)
if uploaded is not None:
    img = Image.open(uploaded).convert("RGB").resize((64,64))
    st.image(img, caption="Uploaded image", use_column_width=False)
    arr = np.array(img)/255.0
    arr = arr.reshape(1,64,64,3)
    age_input = np.array([[age/100.0]], dtype=float)
    model_path = os.path.join(os.path.dirname(__file__), "..", "saved_model", "model.h5")
    if not os.path.exists(model_path):
        st.error("Saved model not found. Run notebooks/train_model.ipynb to train the model and create saved_model/model.h5")
    else:
        model = tf.keras.models.load_model(model_path)
        pred_prob = model.predict({"img_input":arr, "age_input":age_input})[0][0]
        pred = 1 if pred_prob>0.5 else 0
        genders = {0:"Male", 1:"Female"}
        st.write(f"Predicted label: **{genders[pred]}** (prob {pred_prob:.3f})")
        if 20 <= age <= 30:
            st.info("Note: For ages between 20 and 30 the model was trained to follow the hair-length-based rule: long hair -> Female, short hair -> Male.")
